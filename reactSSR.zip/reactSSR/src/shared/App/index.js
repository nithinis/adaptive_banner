import React, { Component } from 'react';
import {Desktop, Tablet, Mobile} from '../components/ResponsiveContainer';
import DesktopBanner from '../components/banner/DesktopBanner';
import TabletBanner from '../components/banner/TabletBanner';
import MobileBanner from '../components/banner/MobileBanner';


class App extends Component {
  render() {
    return (
      <div className="App">test2
      <Mobile clientWidth={this.props.clientWidth}><MobileBanner /></Mobile>
        <Tablet clientWidth={this.props.clientWidth}><TabletBanner /></Tablet>
        <Desktop clientWidth={this.props.clientWidth}><DesktopBanner /></Desktop>
      </div>
    );
  }
}

export default App;
