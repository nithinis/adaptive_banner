import React from 'react';

const MobileBanner = () => (<div>Responsive component for Mobile</div>);

export default MobileBanner;
