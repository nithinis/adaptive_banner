import path from 'path';
import express from 'express';

import React from 'react';
import { renderToString } from "react-dom/server"
import App from '../shared/App';

const app=express();
const publicPath = express.static('public');

app.use(publicPath);

function getClientScreenWidth(){
  // hardcoding client width for now
  //use some serverside methods to get client screen Width
  //return 1080; //desktop
  return 800; //Tablet
  //return 500; //mobile
}

app.get("*", (req, res, next) => {
  const markup = renderToString(
    <App clientWidth={getClientScreenWidth()}/>
  )

  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>SSR with RR</title>
        <!-- uncomment this script to enable client side react -->
        <!-- <script type="text/javascript" src="/bundle.js" defer></script> -->
      </head>

      <body>
        <div id="app">${markup}</div>
      </body>
    </html>
  `)
});


const port = process.env.PORT || 8080;
app.listen(port);
console.log(`Listening at http://localhost:${port}`);
