import React from 'react';
import Responsive, {toQuery} from 'react-responsive';

const viewPorts = {
  large: {minWidth: "992px"},
  medium: {minWidth: "768px", maxWidth:"991px"},
  small: { maxWidth: "767px"}
}
const Desktop = props => <Responsive {...props} query={ toQuery(viewPorts.large)} />;
const Tablet = props => <Responsive {...props} query={ toQuery(viewPorts.medium)} />;
const Mobile = props => <Responsive {...props} query={ toQuery(viewPorts.small)} />;

export { Desktop, Tablet, Mobile };
