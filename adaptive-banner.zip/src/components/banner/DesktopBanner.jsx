import React from 'react';

const DesktopBanner = () => (<div>Desktop responsive component</div>)

export default DesktopBanner;
