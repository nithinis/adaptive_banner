import React from 'react';

const TabletBanner = () => (<div>Responsive Tablet component</div>);

export default TabletBanner;
