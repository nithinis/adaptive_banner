import React, { Component } from 'react';
import {Desktop, Tablet, Mobile} from './components/ResponsiveContainer';
import DesktopBanner from './components/banner/DesktopBanner';
import TabletBanner from './components/banner/TabletBanner';
import MobileBanner from './components/banner/MobileBanner';
import './App.css';


class App extends Component {
  render() {
    return (
      <div className="App">
      <Mobile><MobileBanner /></Mobile>
        <Tablet><TabletBanner /></Tablet>
        <Desktop><DesktopBanner /></Desktop>
      </div>
    );
  }
}

export default App;
